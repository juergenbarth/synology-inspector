/**
 * pdf-export.js — Members-only PDF export
 *
 * This file is NOT part of the public distribution.
 * Members receive it as part of the Members ZIP.
 *
 * When loaded, it sets window.JKLP_PDF_EXPORT = true, which causes
 * app.js to render the "Export PDF" button in the context bar.
 *
 * Depends on (already loaded by index.html):
 *   i18n.js            — t(), getCurrentLanguage()
 *   compliance-view.js — complianceState, _cachedFindings, rerenderCompliance()
 *   compliance-engine.js — calculateSecurityScore(), scoreToGrade(), scoreToVerdict()
 *   app.js             — _parseResult, escapeHtml(), formatFileSize()
 */

window.JKLP_PDF_EXPORT = true;

function exportToPDF() {
    if (!_cachedFindings || !_parseResult) return;

    // ── Save current UI state ────────────────────────────────────────────────
    const savedSeverity  = complianceState.severityFilter;
    const savedFramework = complianceState.frameworkFilter;
    const savedExpanded  = new Set(complianceState.expandedIds);

    // ── Expand all findings, clear all filters ───────────────────────────────
    complianceState.severityFilter  = null;
    complianceState.frameworkFilter = null;
    complianceState.expandedIds     = new Set(_cachedFindings.map(f => f.id));
    rerenderCompliance();

    // ── Build metadata ───────────────────────────────────────────────────────
    const score   = calculateSecurityScore(_cachedFindings);
    const grade   = scoreToGrade(score);
    const verdict = scoreToVerdict(score);
    const gradeColor = score >= 80 ? '#256f3a' : score >= 60 ? '#e76500' : '#aa0808';

    const { info, config, fileName, fileSize } = _parseResult;
    const version = info.dsm_majorversion
        ? `${info.dsm_majorversion}.${info.dsm_minorversion || '0'} (Build ${info.dsm_buildnumber || '?'})`
        : '—';
    const model = info.unique
        ? info.unique.replace(/^synology_[^_]+_/, '').toUpperCase()
        : '—';
    let hostname = '—';
    try { hostname = JSON.parse(config?.get('NETWORK_GENERAL_config') || '{}')?.config?.server_name || '—'; } catch (_) {}
    const locale  = getCurrentLanguage() === 'de' ? 'de-DE' : 'en-GB';
    const dateStr = new Date().toLocaleDateString(locale, {
        year: 'numeric', month: 'long', day: 'numeric'
    });

    const failCount = _cachedFindings.filter(f => f.status === 'fail').length;
    const passCount = _cachedFindings.filter(f => f.status === 'pass').length;

    // ── Inject report header ─────────────────────────────────────────────────
    const header = document.createElement('div');
    header.id = 'pdf-report-header';
    header.innerHTML = `
        <div class="pdf-hdr-top">
            <img src="img/logo-jklp.png" alt="JKLP Consulting" class="pdf-hdr-logo">
            <div class="pdf-hdr-titles">
                <div class="pdf-hdr-tool">
                    Synology Inspector
                    <span class="pdf-hdr-version">v1.0</span>
                </div>
                <div class="pdf-hdr-subtitle">${t('pdfReportTitle')}</div>
            </div>
            <div class="pdf-hdr-score-block">
                <span class="pdf-hdr-grade" style="color:${gradeColor}">${grade}</span>
                <div class="pdf-hdr-score-detail">
                    <span class="pdf-hdr-score-num" style="color:${gradeColor}">${score}/100</span>
                    <span class="pdf-hdr-verdict" style="color:${gradeColor}">${escapeHtml(verdict)}</span>
                </div>
            </div>
        </div>
        <div class="pdf-hdr-divider"></div>
        <div class="pdf-hdr-meta">
            <div class="pdf-hdr-meta-cell">
                <span class="pdf-hdr-meta-label">${t('labelModel')}</span>
                <span class="pdf-hdr-meta-value">${escapeHtml(model)}</span>
            </div>
            <div class="pdf-hdr-meta-cell">
                <span class="pdf-hdr-meta-label">${t('labelHostname')}</span>
                <span class="pdf-hdr-meta-value">${escapeHtml(hostname)}</span>
            </div>
            <div class="pdf-hdr-meta-cell">
                <span class="pdf-hdr-meta-label">${t('labelDSMVersion')}</span>
                <span class="pdf-hdr-meta-value">${escapeHtml(version)}</span>
            </div>
            <div class="pdf-hdr-meta-cell">
                <span class="pdf-hdr-meta-label">${t('labelFileName')}</span>
                <span class="pdf-hdr-meta-value">${escapeHtml(fileName)}</span>
            </div>
            <div class="pdf-hdr-meta-cell">
                <span class="pdf-hdr-meta-label">${t('pdfAnalysedOn')}</span>
                <span class="pdf-hdr-meta-value">${escapeHtml(dateStr)}</span>
            </div>
            <div class="pdf-hdr-meta-cell">
                <span class="pdf-hdr-meta-label">${t('pdfIssues')}</span>
                <span class="pdf-hdr-meta-value">${failCount} ${t('findingPlural')} · ${passCount} ${t('severityPass')}</span>
            </div>
        </div>
    `;
    // Insert BEFORE #app so the header appears at the top of the print output
    const appEl = document.getElementById('app');
    document.body.insertBefore(header, appEl);

    // ── Inject contact footer after #app ─────────────────────────────────────
    const footer = document.createElement('div');
    footer.id = 'pdf-report-footer';
    footer.innerHTML = `
        <div class="pdf-ftr-contact">
            <span class="pdf-ftr-name">Jürgen Barth · JKLP Consulting</span>
            <span class="pdf-ftr-sep">|</span>
            <a class="pdf-ftr-link" href="mailto:contact@jklp.io">contact@jklp.io</a>
            <span class="pdf-ftr-sep">|</span>
            <a class="pdf-ftr-link" href="https://jklp.io">jklp.io</a>
            <span class="pdf-ftr-sep">|</span>
            <a class="pdf-ftr-link" href="${YOUTUBE_CHANNEL_URL}">youtube.com/@navigio1</a>
        </div>
    `;
    appEl.after(footer);

    document.body.classList.add('pdf-printing');

    // ── Cleanup after print dialog closes ────────────────────────────────────
    window.addEventListener('afterprint', function cleanup() {
        header.remove();
        footer.remove();
        document.body.classList.remove('pdf-printing');
        complianceState.severityFilter  = savedSeverity;
        complianceState.frameworkFilter = savedFramework;
        complianceState.expandedIds     = savedExpanded;
        rerenderCompliance();
    }, { once: true });

    window.print();
}
